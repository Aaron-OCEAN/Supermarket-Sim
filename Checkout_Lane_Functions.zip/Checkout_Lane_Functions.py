import random  # Imports the random function


class CheckoutLane:  # Defines the checkout lane class and every field to be used
    def __init__(self, lane_type, capacity, status="closed"):
        self.lane_type = lane_type
        self.status = status
        self.customers = []
        self.capacity = capacity

    def open_lane(self):  # Function to open lanes
        self.status = 'open'

    def close_lane(self):  # Function to close lanes
        self.status = 'closed'

    def add_customer(self, customer):  # Function that adds customers to the lanes
        if len(self.customers) < self.capacity:  # First checks that the amount of customers is below capacity
            self.customers.append(customer)  # Adds the customer
            print(f"Customer {customer.id} added to", self.lane_type, "lane")
            return True
        else:
            print(self.lane_type, "full")  # Returns false if capacity has been reached
            return False

    def remove_customer(self, customer):  # Function that removes customer from lane (used for testing purposes)
        if customer in self.customers:
            self.customers.remove(customer)
            print("Customer removed from the lane")
        else:
            print("customer not found in lane")

    def pop_customer(self):  # Function that takes the first customer waiting in queue and assigns them the value p
        if len(self.customers) == 0:
            return None
        
        p = self.customers[0]
        del self.customers[0]
        return p

    def display_lane_status(self):  # Function that shows the lane status (used for testing purposes)
        print(self.lane_type, "lane", self.status, "->", self.customers if self.status == 'open' else 'closed')

    def move_lane(self, other_lane, number_of_customers):  # Function that moves customers from one lane to another (used for testing purposes)
        if other_lane.capacity >= (len(other_lane.customers) + number_of_customers):
            for i in range(0, number_of_customers):
                other_lane.add_customer(self.pop_customer())

            return True
        else:
            return False

    def serve(self):  # Main function that processes the customer
        if self.status == "closed":  # Displays closed lanes
            print(self.lane_type, "Lane is closed.")
            return

        if self.lane_type == "Regular":
            c = self.pop_customer()
            if c is not None:  # p == c and along as c has a value a customer will be processed
                print(f"Just served customer {c.id} at a regular lane. This took {c.basket_size * 4} seconds.")  # Works out time taken to serve
                # Check lottery
                lottery_num_1 = random.randint(1, 100)
                lottery_num_2 = random.randint(1, 100)
                if lottery_num_1 == lottery_num_2:
                    print(f"Customer {c.id} has won a lottery ticket! and has left the queue")
                else:
                    print(f"Customer {c.id} has not won a lottery ticket and has left the queue.")

            else:
                print(self.lane_type, "Lane is empty.")

        else:
            for i in range(0, 8):  # removes customers from self-service checkout lanes
                c = self.pop_customer()
                if c is not None:  # If a customer can't be removed the lane is empty
                    print(f"Just served customer {c.id} at a self-service lane. This took {c.basket_size * 6} seconds.")
                else:
                    print(self.lane_type, "Lane is empty.")


# Test the CheckoutLane class
def test_checkout_lane():
    lane = CheckoutLane("Regular", 5)

    print("\n### Initial Lane Status ###")
    lane.display_lane_status()
    lane.add_customer("Customer1")
    lane.add_customer("Customer2")
    lane.add_customer("Customer3")
    lane.add_customer("Customer4")
    lane.add_customer("Customer5")
    lane.add_customer("Customer6")

    print("\n### Updated Lane Status ###")
    lane.display_lane_status()

    print("\n### Removing customer ###")
    lane.remove_customer("Customer1")

    print("\n### Updated Lane Status ###")
    lane.display_lane_status()

    print("\n### Opening Lane ###")
    lane.open_lane()

    print("\n### Updated Lane Status ###")
    lane.display_lane_status()

    print("\n### Closing lane ###")
    lane.close_lane()


# Run the test
# test_checkout_lane()
