from Checkout_Lane_Functions import *
import random
import time


class Customer:
    def __init__(self, ID):
        self.id = ID
        self.basket_size = random.randint(1, 30)


def add_customers_to_lanes(customers, lanes):
    for i in range(len(customers)):
        customer = customers.pop(0)
        if customer.basket_size >= 10:  # If they have 10 or more items they MUST go into a regular lane
            if not add_customer_to_regular_lane(lanes, 0, no_of_regular_lanes - 1, customer):  # If you cant add the customer to the regular lane it means the lanes are saturated
                customers.append(customer)  # and adds the customer back into the array
                continue

        else:  # otherwise they should go into the self-service lane, but if this is full they may enter a regular lane
            if lanes[-1].status == "closed":
                lanes[-1].open_lane()

            if not lanes[-1].add_customer(customer):
                if not add_customer_to_regular_lane(lanes, 0, no_of_regular_lanes - 1, customer):  # If not the customer will be added to the regular lane if possible
                    customers.append(customer)


def add_customer_to_regular_lane(lanes, start_of_regular, end_of_regular, customer):
    # Iterate over the regular lanes in the array of lanes
    for i in range(start_of_regular, end_of_regular + 1):
        if lanes[i].status == "open":  # If the lane is open
            if lanes[i].add_customer(customer):  # If the lane is not full
                break  # The customer has been added by the call above, and we may end the function

            else:  # If the lane is full
                # Check if this is the last regular lane
                if i < end_of_regular and lanes[i+1].status == "closed":  # If not, open the next lane and continue to the next iteration
                    lanes[i+1].open_lane()
                    print("Opening a new lane.")

                elif i >= end_of_regular:  # If it is the last lane, then the lanes have been saturated and the program should be terminated
                    print("Lanes saturated.")
                    return False
                
        elif i == 0:
            lanes[i].open_lane()  # If the first regular lane is closed, open it and add a customer
            lanes[i].add_customer(customer)
            break
                
    return True


def simulation():
    # Create array of customers
    customers = [Customer(ID) for ID in range(0, random.randint(1, 10))]
    current_ID = len(customers)

    # Create the lanes.
    # Note that because of how the rest of the algorithm works, the regular lanes must be contiguous in the array, and the array must end with
    # the self-service lane.
    lanes = [
        CheckoutLane("Regular", 5, status="open"),
        CheckoutLane("Regular", 5),
        CheckoutLane("Regular", 5),
        CheckoutLane("Regular", 5),
        CheckoutLane("Regular", 5),
        CheckoutLane("Self",   15, status="open")
    ]

    while True:
        try:
            cycles = int(input("How many cycles would you like the program to run (max 100) > "))
        except ValueError:
            print("That's an incorrect format please try again")
            continue

        if cycles > 100 or cycles < 1:
            print("That's a wrong value please try again")
            continue

        break

    while True:
        try:
            chance_of_new_customer = float(input("Chance of creating new customers? (0.0 to 1) > "))
        except ValueError:
            print("That's an incorrect format please try again")
            continue

        if chance_of_new_customer > 1 or chance_of_new_customer < 0:
            print("That's a wrong value please try again")
            continue

        break

    # Add the generated customers to the new lanes
    add_customers_to_lanes(customers, lanes)

    # Start the simulation
    for cycle in range(cycles):
        print(f"\n\n---- CYCLE {cycle + 1} ----\n")

        if (random.randint(0, 100) / 100) < chance_of_new_customer and len(customers) < 40:
            for customer in [Customer(ID) for ID in range(current_ID, current_ID + random.randint(1, 10))]:
                customers.append(customer)
                current_ID += 1
                print(f"Created new customer ({customer.id}) with {customer.basket_size} items in their basket.")

        add_customers_to_lanes(customers, lanes)

        for lane in lanes:
            lane.serve()  # starts to serve all the next available customers in a lane
            if len(lane.customers) == 0 and lane.status == "open":
                lane.close_lane()
                print(f"{lane.lane_type}Lane closed due to it being empty.")

        time.sleep(1)


if __name__ == "__main__":
    no_of_regular_lanes = 5
    simulation()
    while input("Would you like to re-run the simulation, enter (no) to stop the program > ") != "no":
        simulation()
